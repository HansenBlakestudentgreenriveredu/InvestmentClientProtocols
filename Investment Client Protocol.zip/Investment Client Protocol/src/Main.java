// Blake Hansen
// 3/7/2024
// Investment Client Protocol Assignment
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}